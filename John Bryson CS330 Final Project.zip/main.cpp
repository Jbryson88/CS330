
#include <GLAD/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>

// Function prototypes
void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void processInput(GLFWwindow* window);
void renderBigBen();
void renderCube();
void renderCylinder();
void renderCone();
void applyTextures();
void setupLighting();
void setupCameraControls();

// Settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;

int main()
{
    // Initialize GLFW
    if (!glfwInit())
    {
        std::cout << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    // Create a GLFW window
    GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Big Ben 3D Scene", NULL, NULL);
    if (!window)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);

    // Initialize GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
    {
        std::cout << "Failed to initialize GLAD" << std::endl;
        return -1;
    }

    // Set viewport
    glViewport(0, 0, SCR_WIDTH, SCR_HEIGHT);
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // Apply textures
    applyTextures();

    // Set up lighting
    setupLighting();

    // Main render loop
    while (!glfwWindowShouldClose(window))
    {
        // Process input
        processInput(window);

        // Clear the screen
        glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Render the Big Ben tower and objects
        renderBigBen();

        // Swap buffers and poll IO events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Terminate GLFW
    glfwTerminate();
    return 0;
}

// Handle input
void processInput(GLFWwindow* window)
{
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);
}

// Adjust viewport on window resize
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// Render the Big Ben tower
void renderBigBen()
{
    // Base of the tower (Box)
    renderCube();

    // Clock faces (Cylinders)
    for (int i = 0; i < 4; i++)
    {
        renderCylinder();
    }

    // Roof of the tower (Cone + Tapered Cylinder)
    renderCone();
}

// Render a basic cube (used for tower base)
void renderCube()
{
    // Set up vertices for the cube
    float vertices[] = {
        // Position           // Texture Coords
        -0.5f, -0.5f, -0.5f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 1.0f
    };

    unsigned int indices[] = {
        0, 1, 2, 2, 3, 0,
        4, 5, 6, 6, 7, 4,
        0, 1, 5, 5, 4, 0,
        2, 3, 7, 7, 6, 2,
        0, 3, 7, 7, 4, 0,
        1, 2, 6, 6, 5, 1
    };

    // Setup code for rendering the cube here (VBO, VAO, EBO, etc.)
}

// Render a basic cylinder for the clock face
void renderCylinder()
{
    // Code for creating and rendering a low-poly cylinder
    // Can be done using GL_TRIANGLE_STRIP or GL_TRIANGLE_FAN
}

// Render a basic cone for the roof
void renderCone()
{
    // Code for creating and rendering a low-poly cone
}

// Load and apply textures for the clock face and tower base
void applyTextures()
{
    // Load texture for clock face (royalty-free texture)
    GLuint textureClockFace;
    glGenTextures(1, &textureClockFace);
    glBindTexture(GL_TEXTURE_2D, textureClockFace);
    // Texture wrapping, filtering options here...

    // Load image data (use an image loading library like stb_image.h)
    // stbi_load("path_to_clock_face_texture", &width, &height, &nrChannels, 0);
    // glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
    // glGenerateMipmap(GL_TEXTURE_2D);
    
    // Repeat similar steps for other textures (tower body, etc.)
}

// Set up lighting (point light and colored directional light)
void setupLighting()
{
    // Point light setup
    glUniform3f(glGetUniformLocation(shaderProgram, "light.position"), lightPos.x, lightPos.y, lightPos.z);
    glUniform3f(glGetUniformLocation(shaderProgram, "light.ambient"), 0.2f, 0.2f, 0.2f);
    glUniform3f(glGetUniformLocation(shaderProgram, "light.diffuse"), 0.5f, 0.5f, 0.5f);
    glUniform3f(glGetUniformLocation(shaderProgram, "light.specular"), 1.0f, 1.0f, 1.0f);

    // Colored directional light
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.direction"), -0.2f, -1.0f, -0.3f);
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.ambient"), 0.1f, 0.1f, 0.1f);
    glUniform3f(glGetUniformLocation(shaderProgram, "dirLight.diffuse"), 0.8f, 0.7f, 0.2f); // Yellowish light
}

// Set up WASD camera movement
void setupCameraControls()
{
    // WASD controls for movement on the XZ-plane
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) // Forward
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) // Backward
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) // Left
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) // Right
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) // Up
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) // Down
}
